---
name: Photos Discovery Research
colors:
  surface: '#fff8f5'
  surface-dim: '#e0d8d5'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2ee'
  surface-container: '#f4ece8'
  surface-container-high: '#eee7e3'
  surface-container-highest: '#e9e1dd'
  on-surface: '#1e1b19'
  on-surface-variant: '#3e4948'
  inverse-surface: '#33302d'
  inverse-on-surface: '#f7efeb'
  outline: '#6e7978'
  outline-variant: '#bec9c7'
  surface-tint: '#046a67'
  primary: '#005452'
  on-primary: '#ffffff'
  primary-container: '#0f6e6b'
  on-primary-container: '#9dede9'
  inverse-primary: '#85d4d0'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#005725'
  on-tertiary: '#ffffff'
  tertiary-container: '#007233'
  on-tertiary-container: '#91f4a3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a1f1ec'
  primary-fixed-dim: '#85d4d0'
  on-primary-fixed: '#00201f'
  on-primary-fixed-variant: '#00504d'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#95f8a7'
  tertiary-fixed-dim: '#79db8d'
  on-tertiary-fixed: '#00210a'
  on-tertiary-fixed-variant: '#005323'
  background: '#fff8f5'
  on-background: '#1e1b19'
  surface-variant: '#e9e1dd'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-lg:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-md:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  body-md-medium:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  data-metric-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  data-metric-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system is tailored for an internal research intelligence tool that empowers Product Managers to evaluate, prioritize, and decide which retrieval problems to investigate. The visual philosophy departs from sterilized corporate software and consumer-facing photo apps; it embraces the warmth, weight, and scholarly authority of a curator’s research notebook combined with the sharp operational discipline of a financial terminal.

### Design Principles
- **Scholarly & Analytical:** Qualitative human nuance sits side-by-side with hard ranking metrics. Editorial serif headers give weight to real user verbatim quotes and retrieval opportunity titles, while structured tabular layouts anchor numerical analysis.
- **Calm Warmth over Stark Sterile Surfaces:** Instead of blinding cold whites (#FFFFFF canvases with #000000 text), the canvas leverages warm stone, bone, and oat tones. This significantly reduces optical fatigue during prolonged synthesis and ranking sessions.
- **High Information Density with Absolute Clarity:** Screen space is reserved for structured intelligence—no decorative illustrations, empty placeholder graphics, or gratuitous iconography. Visual hierarchy is achieved through precise typographic weight, low-contrast structural rules, and intentional accent pops.
- **Human-Grounded Decision Making:** User pain points are presented as dignified qualitative narratives, reinforced by quantitative scores (1.00–5.00) and visible PM override attribution markers.

## Colors

The palette is anchored by a warm mineral foundation, high-contrast dark stone ink, and a single dominant deep teal for interactive and active states. Functional accents are restrained and strictly tied to data taxonomy and score bands.

### Palette Architecture
- **Canvas & Structural Surfaces:**
  - `page-bg`: `#F6F4EF` (Warm stone, grounding all views)
  - `surface-card`: `#FFFFFF` (Crisp container background)
  - `surface-subtle`: `#FAF8F5` (Table header fills, hover states)
  - `surface-tint`: `#F0ECE1` (Active card selection, filter wells, rail background)
  - `surface-contrast`: `#EFECE6` (Segmented control wells, secondary buttons)
  - `border-subtle`: `#E6E1D8` (Canonical 1px card and cell outline)
  - `border-strong`: `#D6CEBE` (Dividers, active inputs, column bounds)

- **Typography & Ink:**
  - `text-primary`: `#1C1917` (Deep warm obsidian ink)
  - `text-secondary`: `#78716C` (Mid stone for descriptions, metadata)
  - `text-tertiary`: `#A8A29E` (Subtle captions, inactive placeholders, table borders)
  - `text-inverse`: `#FFFFFF`

- **Interactive Primary:**
  - `accent-primary`: `#0F6E6B` (Deep teal for primary action buttons, active navigation, active filters, selected radio/checkbox borders, hyperlinked items)
  - `accent-primary-hover`: `#0B5452`
  - `accent-primary-subtle`: `#E6F2F1` (Badge backgrounds, soft active chips)

- **Severity & Prioritization Bands:**
  - **High Band (P0/P1):** Text `#166534`, Tint/Border `#DCFCE7` / `#15803D`
  - **Medium Band (P2):** Text `#B45309`, Tint/Border `#FEF3C7` / `#D97706`
  - **Low Band (P3):** Text `#57534E`, Tint/Border `#F5F5F4` / `#78716C`
  - **PM Override Token:** Foreground `#0F6E6B`, Background `#E6F2F1`, Border `#99D5D3`. Used to distinguish algorithmic baselines from human-calibrated scoring.

## Typography

Typography establishes an intellectual equilibrium between qualitative inquiry and quantitative rigor.

- **Editorial Headlines & Opportunity Titles (`Newsreader`):** Applied exclusively to opportunity titles, verbatim search queries, user interview excerpts, and overarching research themes. It lends dignity, humanity, and narrative significance to user frustration points.
- **Interface & Operational Text (`IBM Plex Sans`):** Clean, disciplined, and optimized for dense information architectures. Handles UI controls, labels, tooltips, table bodies, and navigation rails with no stylistic distortion.
- **Score Data & Metrics (`JetBrains Mono`):** Dedicated to numerical performance indicators, sample sizes (N=), confidence intervals, and the 1.00–5.00 opportunity scoring scales. Tabular figures guarantee uniform vertical alignment across dense ranking matrices.

## Layout & Spacing

The layout is built for focused analysis on desktop displays, optimized for a standard 1440px wide viewport with zero wasted horizontal or vertical headroom.

### Three-Pane Architectural Model
- **Left Navigation Rail (Fixed 220px):** Permanent structural anchor containing dataset switchers, taxonomy levels, saved views, and research queries. Background: `#F0ECE1`, right border 1px `#E6E1D8`.
- **Center Analysis Stage (Fluid Canvas):** Maximized for high-density ranking tables, split opportunity dossiers, and comparative retrieval matrices. Centered in viewport with standard 24px horizontal gutters.
- **Right Filter & Calibration Drawer (Sticky 280px):** Fixed utility column housing multidimensional facet filters (e.g., query modalities, error classes, volume percentiles) and scoring weight sliders. Background: `#FAF8F5`, left border 1px `#E6E1D8`.

### Layout Rules
- Tables and list rows use compressed vertical rhythms (`space-sm` for table rows, yielding 36px–40px compact row targets).
- Gaps between logical analysis cards are constrained to `space-md` (12px) to `space-lg` (16px), retaining structural cohesion without visual dilution.

## Elevation & Depth

Visual hierarchy is communicated via clean planar boundaries and tone rather than dropped shadows.

### Elevation Principles
- **No Drop Shadows:** Default elements sit flat on the `#F6F4EF` canvas with crisp 1px `#E6E1D8` containment borders.
- **Micro Ambient Elevation (Level 1):** Reserved strictly for hovering cards or draggable ranking priorities: `0 1px 3px rgba(28, 25, 23, 0.05)`.
- **Tonal Stepping (Depth via Color):**
  - Layer 0 (Base Canvas): `#F6F4EF`
  - Layer 1 (Card / Table Surface): `#FFFFFF`
  - Layer 2 (Hover / Filter Well): `#FAF8F5`
  - Layer 3 (Active / Focus Inset): `#F0ECE1`
- **Floating Overlays & Menus:** Dropdowns, popovers, and PM override selectors use `#FFFFFF` surfaces with a 1px solid border `#D6CEBE` and a disciplined shadow: `0 4px 16px -2px rgba(28, 25, 23, 0.08)`.

## Shapes

The geometric framework balances humanized warmth with structured software utility.

- **Cards and Major Containers:** Strictly 12px border radius (`rounded-lg`), softening the interface without appearing juvenile or bubbly.
- **Form Elements & Interactive Controls:** Standard 6px to 8px border radius (`rounded-md`), ensuring input fields and compact buttons maintain crisp architectural alignments.
- **Pills & Status Badges:** Fully rounded 9999px for status chips, severity bands, and the small PM Override indicator tag to instantly separate metadata tags from rectangular interactive cards.
- **Borders:** Universal 1px solid stroke width across cards, dividers, tables, and inputs.

## Components

### Buttons
- **Primary:** Filled `#0F6E6B`, text `#FFFFFF`, 8px radius, height 32px (compact) or 36px (regular). Hover: `#0B5452`. Focus: 2px offset ring `#0F6E6B`.
- **Secondary:** Surface `#FFFFFF`, border 1px `#E6E1D8`, text `#1C1917`. Hover: `#F0ECE1`, border `#D6CEBE`.
- **Tertiary / Ghost:** No border, transparent background, text `#78716C`. Hover: `#F0ECE1`, text `#1C1917`.

### Score Bands & Status Chips
Pill-shaped badges with mono tabular numeric outputs:
- **High Opportunity (P0/P1):** Green background `#DCFCE7`, border `#BBF7D0`, text `#166534`.
- **Medium Opportunity (P2):** Amber background `#FEF3C7`, border `#FDE68A`, text `#B45309`.
- **Low Opportunity (P3):** Stone background `#F5F5F4`, border `#E7E5E4`, text `#57534E`.
- **PM Override Tag:** Height 18px, padding 0 6px, radius 9999px, background `#E6F2F1`, border 1px `#99D5D3`, text `#0F6E6B` (`font-weight: 700; font-size: 10px; font-family: IBM Plex Sans`). Directly adjacent to the edited score, with the strikethrough algorithmic score rendered in `text-tertiary` `#A8A29E` mono.

### Tables & Data Grids
- **Header:** Background `#FAF8F5`, 1px bottom border `#E6E1D8`, text `label-sm` (`#78716C`, uppercase, tracking).
- **Row:** Height 38px, alternating hover `#FAF8F5`, baseline border 1px `#F0ECE1`.
- **Numerical Alignment:** Mono cells right-aligned, text cells left-aligned, category chips centered.

### Cards
- Surface `#FFFFFF`, 12px radius, 1px border `#E6E1D8`.
- Section headers within cards utilize `Newsreader` for opportunity labels, paired with a subhead in `IBM Plex Sans` for context and tabular metrics floating on the right edge.

### Input Fields & Filter Toggles
- Inputs feature background `#FFFFFF`, border 1px `#E6E1D8`, 6px radius, placeholder color `#A8A29E`.
- Filter checkboxes and radio elements use `#0F6E6B` when checked, with a warm stone unselected state.